﻿using System;
using System.Collections.Generic;

namespace ertekeloRendszer.Models;

public partial class Végsőpont2
{
    public string Nev { get; set; } = null!;

    public decimal? VégsőPont { get; set; }
}
